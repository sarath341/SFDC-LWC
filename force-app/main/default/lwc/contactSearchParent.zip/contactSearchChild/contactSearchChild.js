import { LightningElement } from 'lwc';

export default class ContactSearchChild extends LightningElement {
    searchText;

    handleSearchText(event){
        this.searchText = event.target.value;
    }

    searchButton(){
        this.searchText = this.searchText;
        const eventRef = new CustomEvent('contactclick',{detail:{toSearch:this.searchText}});
        this.dispatchEvent(eventRef);
    }
}