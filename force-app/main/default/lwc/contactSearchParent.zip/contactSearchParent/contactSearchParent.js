import { LightningElement } from 'lwc';
import getContacts from '@salesforce/apex/ConController.getContacts';
export default class ContactSearchParent extends LightningElement {
    contacts;
    toSearch = '';
    handleContactClick(event) {
        this.toSearch = event.detail.toSearch;
        console.log('Receieved event from Child: ' + this.toSearch);
        this.conHandler();
    }

    conHandler() {
        getContacts({ textkey: this.toSearch })
            .then((result) => {
                this.contacts = result;
                console.log(this.contacts)
                })
            .catch((issue) => {
                this.contacts = null;
            })
    }
}